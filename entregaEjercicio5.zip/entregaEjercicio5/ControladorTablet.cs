using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ControladorTablet : MonoBehaviour
{
    public TextMeshProUGUI textoCantidad;
    public ControladorTomates scriptCtrlTomates;

    public void MostrarCantidadActualizadaTomates()
    {
        textoCantidad.text = scriptCtrlTomates.DarCantidadTomatesMaduros().ToString();
    }
}
