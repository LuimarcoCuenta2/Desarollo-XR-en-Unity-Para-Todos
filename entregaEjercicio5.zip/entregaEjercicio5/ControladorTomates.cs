using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControladorTomates : MonoBehaviour
{
    public GameObject[] objetosTomates;

    void Start()
    {
        objetosTomates = GameObject.FindGameObjectsWithTag("tomates");
    }

    public int DarCantidadTomatesMaduros()
    {
        int contador = 0;

        foreach (GameObject alimento in objetosTomates)
        {
            if (alimento.GetComponent<ControladorMaduracion>().estaMaduro == true)
            {
                contador++;
            }
        }

        return contador;
    }
}
