using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CrearCincoFrutas : MonoBehaviour
{
    public GameObject frutaACopiar;

    void Start()
    {
        GameObject fruta1 = Instantiate(frutaACopiar, transform);
        fruta1.transform.localPosition = new Vector3(0f, 0f, 0f);

        GameObject fruta2 = Instantiate(frutaACopiar, transform);
        fruta2.transform.localPosition = new Vector3(0.004f, 0.008f, 0.019f);

        GameObject fruta3 = Instantiate(frutaACopiar, transform);
        fruta3.transform.localPosition = new Vector3(0.008f, 0.016f, 0.038f);

        GameObject fruta4 = Instantiate(frutaACopiar, transform);
        fruta4.transform.localPosition = new Vector3(0.012f, 0.024f, 0.057f);

        GameObject fruta5 = Instantiate(frutaACopiar, transform);
        fruta5.transform.localPosition = new Vector3(0.016f, 0.032f, 0.076f);
    }

    void Update()
    {

    }
}
